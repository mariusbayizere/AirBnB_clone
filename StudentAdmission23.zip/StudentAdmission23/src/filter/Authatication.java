package filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class Authatication
 */
@WebFilter("/Authatication")
public class Authatication implements Filter {

    /**
     * Default constructor. 
     */
    public Authatication() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}


    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        HttpSession session = request.getSession(false);

        boolean loggedIn = (session != null && session.getAttribute("user") != null);
        String loginURI = request.getContextPath() + "/login.jsp";

        boolean loginRequest = request.getRequestURI().equals(loginURI);
        boolean loggedInUserRequest = request.getRequestURI().startsWith(request.getContextPath() + "/loginservlet");

        if (loggedIn || loginRequest || loggedInUserRequest) {
            filterChain.doFilter(request, response);
//            chain.doFilter(request, response);
            System.out.println("is corrected ");
        } else {
            response.sendRedirect(loginURI);
     
        System.out.println(" not is corrected ");
        }
    }
	

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
