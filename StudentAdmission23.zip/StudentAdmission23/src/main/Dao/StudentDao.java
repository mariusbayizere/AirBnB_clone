package main.Dao;


import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query; 
import main.Model.Student;
import main.View.HibernateUtil;
//import org.hibernate.Session;
import org.hibernate.Transaction;

public class StudentDao{
	@SuppressWarnings("unused")
	public void saveStudent(Student employee) {
		
		Transaction transaction = null;
		
		try {
			Session session = 
					HibernateUtil.
					getSession().
					getSession();
			
			transaction = session.beginTransaction();
			
			session.save(employee);
			
			transaction.commit();
			
			session.close();
			
		}catch(Exception ex) {
			if(transaction != null) {
				transaction.rollback();
			}
		}
	}
	

	public void updateStudent(Student employee) {
		
		Transaction transaction = null;
		
		try {
			Session session = 
					HibernateUtil.
					getSession().
					getSession();
			
			transaction = session.beginTransaction();
			
			session.update(employee);
			
			transaction.commit();
			
			session.close();
			
		}catch(Exception ex) {
			if(transaction != null) {
				transaction.rollback();
			}
		}
	}	

	
	public void deleteStudent(Student employee) {
	    try {
	        Session session = HibernateUtil.getSession().getSession();
	        session.beginTransaction();
	        session.delete(employee);
	        session.getTransaction().commit();
	        session.close();
	    } catch (Exception ex) {
	        ex.printStackTrace(); // Add this line to print the exception stack trace
	    }
	}
	
    public Student searchStudent(int id){
   try{
  		Session ss = 
				HibernateUtil.
				getSession().
				getSession();
  		Student xbook = (Student) ss.get(Student.class, id);
       ss.close();
       return xbook;
   }catch(Exception ex){
       ex.printStackTrace();
   }
   return null;
}

 
    public List<Student> selectAllStudent() {
        Transaction transaction = null;
        List<Student> student = null;

        try (Session session = HibernateUtil.getSession()) {
            transaction = session.beginTransaction();

            // Perform data retrieval logic here
            student = session.createQuery("FROM Student", Student.class).list();

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return student;
    }  
        
}