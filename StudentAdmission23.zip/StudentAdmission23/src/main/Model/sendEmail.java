package main.Model;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

public class sendEmail {

    public String getRondom() {
        Random rnd = new Random();
        int number = rnd.nextInt(999999);
        return String.format("%06d", number);
    }

    public boolean sendEmail(Student user) {
        boolean test = false;

        String toEmail = user.getEmail();
        String fromEmail = "bayizeremarius119@gmail.com";
        String password = "dadk yiie arzp lerx";

        Properties properties = new Properties();
//        properties.put("mail.smtp.host", "smtp.mail.com");
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.port", "587");
//        properties.put("mail.smtp.socketFactory.port", "587");
//        properties.put("mail.smtp.socketFactory.class", "javax.net.SSLSocketFactory");

        Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, password);
            }
        });

        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(fromEmail));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
            message.setSubject("Subject of the Email");
            message.setText("Register successfully Plsea verify your account using this code :" );
 
            Transport.send(message);
            test = true;
        } catch (MessagingException e) {
            e.printStackTrace();
        }

        return test;
    }
//
//	public void sendEmail(String email, String subject, String content) {
//		// TODO Auto-generated method stub
//		
//	}
}
