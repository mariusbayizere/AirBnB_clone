package main.Model;

import javax.persistence.*;
import java.sql.Date;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;
    private String Firstname;
    private String Lastname;
    private String Email;
    private String password;
    private String Faculty;
    private String Telephone;
    private String Department;
    private Date date;
    private String passwordPictureFileName;
    private String certificatesFileName;
	public Student() {
		super();
	}
	public Student(int id, String firstname, String lastname, String email, String password, String faculty,
			String telephone, String department, Date date, String passwordPictureFileName,
			String certificatesFileName) {
		super();
		this.id = id;
		Firstname = firstname;
		Lastname = lastname;
		Email = email;
		this.password = password;
		Faculty = faculty;
		Telephone = telephone;
		Department = department;
		this.date = date;
		this.passwordPictureFileName = passwordPictureFileName;
		this.certificatesFileName = certificatesFileName;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFaculty() {
		return Faculty;
	}
	public void setFaculty(String faculty) {
		Faculty = faculty;
	}
	public String getTelephone() {
		return Telephone;
	}
	public void setTelephone(String telephone) {
		Telephone = telephone;
	}
	public String getDepartment() {
		return Department;
	}
	public void setDepartment(String department) {
		Department = department;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getPasswordPictureFileName() {
		return passwordPictureFileName;
	}
	public void setPasswordPictureFileName(String passwordPictureFileName) {
		this.passwordPictureFileName = passwordPictureFileName;
	}
	public String getCertificatesFileName() {
		return certificatesFileName;
	}
	public void setCertificatesFileName(String certificatesFileName) {
		this.certificatesFileName = certificatesFileName;
	}
    
    
//    private String photoFileName;
//    @Lob // Use this annotation to indicate large object data
//    private byte[] image;
    
    
    
    
}
