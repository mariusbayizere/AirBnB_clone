package main.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.Dao.StudentDao;
import main.Model.Student;

/**
 * Servlet implementation class Editservlet
 */
@WebServlet("/Editservlet")
public class Editservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Editservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Student std = null;
		StudentDao dao = new StudentDao();

        int id = Integer.parseInt(request.getParameter("lastname1"));

        std = dao.searchStudent(id);

        if (std != null) {
            request.setAttribute("firstname", std.getFirstname());
            request.setAttribute("lastname", std.getLastname());
            request.setAttribute("email", std.getEmail());
            request.setAttribute("id", std.getId());
            request.getRequestDispatcher("form.jsp").forward(request, response);
        } else {
            System.out.println("Employee not found with id: " + id);
        } 
	}

}
