package main.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.RequestContext;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.hibernate.Session;

import com.sun.mail.iap.Response;

import main.Dao.StudentDao;
import main.Model.Student;
import main.Model.sendEmail;
import main.View.HibernateUtil;

/**
 * Servlet implementation class ServletRequeststud
 */
//@WebServlet("/ServletRequeststud")

@WebServlet("/StudentAdmissionFrom")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
public class StudentAdmissionFrom extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String UPLOAD_DIRECTORY = "resources";
	
	private String saveFile(Part part, String fileNamePrefix) throws IOException {
	    if (part == null) {
	        return null; // Return null if Part object is null
	    }
	    
	    String fileName = getSubmittedFileName(part);
	    String fileDirectory = "C:\\Users\\Marius\\Desktop\\"; // Change to your directory
	    try (InputStream inputStream = part.getInputStream();
	         FileOutputStream outputStream = new FileOutputStream(fileDirectory + fileName)) {
	        byte[] buffer = new byte[1024];
	        int bytesRead;
	        while ((bytesRead = inputStream.read(buffer)) != -1) {
	            outputStream.write(buffer, 0, bytesRead);
	        }
	    }
	    return fileName;
	}

	private String getSubmittedFileName(Part part) {
	    for (String cd : part.getHeader("content-disposition").split(";")) {
	        if (cd.trim().startsWith("filename")) {
	            String fileName = cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
	            return fileName.substring(fileName.lastIndexOf('/') + 1).substring(fileName.lastIndexOf('\\') + 1); // MSIE fix.
	        }
	    }
	    return null;
	}
	
		 @Override
		 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		
		//		doGet(request, response);
			 
			 
			 String firstname = request.getParameter("firstname");
			    System.out.println("firstname:" + firstname);
			    String lastname = request.getParameter("lastname");
			    System.out.println("lastname:" + lastname);
			    String email = request.getParameter("email");
			    String passwords = request.getParameter("password");
			    System.out.println("email:" + email);
			    String faculty = request.getParameter("faculty");
			    String telephone = request.getParameter("telephone");
			    String department = request.getParameter("department");
			    String confirmpassowrd =request.getParameter("confirn-password");

			    Part passwordPicturePart = request.getPart("passwordPicture");
			    Part certificatesPart = request.getPart("certificates");

			    String passwordPictureFileName = null;
			    String certificatesFileName = null;

			    if (passwordPicturePart != null) {
			        passwordPictureFileName = saveFile(passwordPicturePart, "password_picture");
			    }

			    if (certificatesPart != null) {
			        certificatesFileName = saveFile(certificatesPart, "certificates");
			    }

			    sendEmail utilsend = new sendEmail();
			    
			    // Create Student object
			    Student student = new Student();
			    student.setFirstname(firstname);
			    student.setLastname(lastname);
			    student.setEmail(email);
			    student.setFaculty(faculty);
			    student.setTelephone(telephone);
			    student.setDepartment(department);


		        sendEmail emailSender = new sendEmail();

		        // Sending email
		        boolean emailSent = emailSender.sendEmail(student);

		        if (emailSent) {
		            response.getWriter().println("Email sent successfully.");
		        } else {
		            response.getWriter().println("Failed to send email.");
		        }
			    
			    
			    if( passwords.equals(confirmpassowrd)) {
			    	
			    	System.out.println("passord are equal");
			    	student.setPassword(passwords);
			    }
			    else {
			    	System.out.println("passord are no equal");
			    	response.sendRedirect("Admission_Form.jsp");
			    }

			    // Append directory path to filenames
			    String fileDirectory = "C:\\Users\\Marius\\Desktop\\";
			    if (passwordPictureFileName != null) {
			        passwordPictureFileName = fileDirectory + passwordPictureFileName;
			    }
			    if (certificatesFileName != null) {
			        certificatesFileName = fileDirectory + certificatesFileName;
			    }
			    student.setPasswordPictureFileName(passwordPictureFileName);
			    student.setCertificatesFileName(certificatesFileName);

			    // Add student to database
			    Session session = HibernateUtil.getSession();
			    StudentDao obj = new StudentDao();
			    obj.saveStudent(student);
			    System.out.println("Success: " + firstname + " " + passwordPictureFileName + " " + certificatesFileName);
			    session.close();

			    // Redirect or forward to success page
			 
    }
    
    private String getFileExtension(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] tokens = contentDisposition.split(";");
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                String fileName = token.substring(token.indexOf("=") + 2, token.length() - 1);
                return fileName.substring(fileName.lastIndexOf("."));
            }
        }
       return ""; // If no file extension found
    }
}

