package main.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.Dao.StudentDao;
import main.Model.Student;

/**
 * Servlet implementation class update
 */
@WebServlet("/update")
public class update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Student std = null;
		StudentDao dao = new StudentDao();

        int id = Integer.parseInt(request.getParameter("lastname1"));

        System.out.println(id);
		response.sendError(500, "Course retieval Failed");	 
	}			
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//			
//		StudentDao dao = new StudentDao();
//		String firtname = request.getParameter("firstname");
//		String lastname = request.getParameter("lastname");
//		String email = request.getParameter("email");
//		
//		Student std = new Student();
//		std.setFirstname(firtname);
//		std.setLastname(lastname);
//		std.setEmail(email);
//
//		dao.updateStudent(std);
//	}
		

        try {
//            Long id = Long.parseLong(request.getParameter("id"));
        	int id = Integer.parseInt(request.getParameter("Lid"));
        	String manu = request.getParameter("firstname");
        	String arsenal = request.getParameter("lastname");
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            Student std = new Student(id, manu, arsenal, email, password, password, password, password, null, password, password);
            std.setId(id); 

            StudentDao fg = new StudentDao();
            fg.updateStudent(std);
            response.sendRedirect("signup.jsp");
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect("editStudent?id=" + request.getParameter("id")); 
        }
    }
}
		
		




