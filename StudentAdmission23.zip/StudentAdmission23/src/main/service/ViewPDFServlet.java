package main.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewPDFServlet
 */
@WebServlet("/ViewPDFServlet")
public class ViewPDFServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewPDFServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
//		String filename = request.getParameter("filename");
		 String filename = request.getParameter("filename");

		    if (filename == null || filename.isEmpty()) {
		        response.getWriter().println("Filename is required.");
		        return;
		    }

		    // Set content type
		    response.setContentType("application/pdf");

		    // Hardcoded filename
		    filename = "SQL-Commands-Cheat-Sheet.pdf";

		    // Get the PDF file from the given filename
		    String filePath = "C:\\Path\\To\\PDF\\Directory\\" + filename; // Update with your actual directory
		    File pdfFile = new File(filePath);

		    if (!pdfFile.exists()) {
		        response.getWriter().println("PDF file not found: " + filename);
		        return;
		    }

		    // Set response headers
		    response.setHeader("Content-Disposition", "inline; filename=" + filename);

		    // Read and write PDF content to response output stream
		    FileInputStream fileInputStream = new FileInputStream(pdfFile);
		    byte[] buffer = new byte[4096];
		    int bytesRead;
		    while ((bytesRead = fileInputStream.read(buffer)) != -1) {
		        response.getOutputStream().write(buffer, 0, bytesRead);
		    }
		    fileInputStream.close();
		}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
