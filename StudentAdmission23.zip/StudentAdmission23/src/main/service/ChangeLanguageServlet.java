package main.service;

import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ChangeLanguageServlet")
public class ChangeLanguageServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    public ChangeLanguageServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String word = request.getParameter("word");
        String language = request.getParameter("language");
        Locale locale = (language != null && !language.isEmpty()) ? new Locale(language) : Locale.ENGLISH;
        Locale locale1 = (language != null && !language.isEmpty()) ? new Locale(language) : Locale.FRANCE;
//        ResourceBundle messages = ResourceBundle.getBundle("resource.messages", locale);
//        ResourceBundle messages = ResourceBundle.getBundle("resource.messages", locale);
//        ResourceBundle messages1 = ResourceBundle.getBundle("resource.messages", locale1);
        ResourceBundle messages = ResourceBundle.getBundle("/StudentAdmission23/src/resource/messages_en_GB.properties", locale);
        ResourceBundle messages1 = ResourceBundle.getBundle("/StudentAdmission23/src/resource/messages_fr_FR.properties", locale1);
        String translatedWord = messages.getString(word);
        String translatedWord1 = messages1.getString(word);
        request.setAttribute("translatedWord", translatedWord);
        
        request.getRequestDispatcher("/language.jsp").forward(request, response);
    }
}
