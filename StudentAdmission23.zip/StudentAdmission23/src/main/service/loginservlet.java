package main.service;

import java.io.IOException;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import main.Model.Student;
import main.View.HibernateUtil;

//@WebServlet("/loginservlet")
//public class loginservlet extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//
//    public loginservlet() {
//        super();
//    }
//
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.getWriter().append("Served at: ").append(request.getContextPath());
//    }
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        String username = request.getParameter("Email");
//        String password = request.getParameter("password");
//
//        if (username != null && password != null && isValidUser(username, password)) {
//            System.out.println("Login success");
//            response.sendRedirect("signup.jsp");
//        } else {
//            System.out.println("Login failed: incorrect credentials");
//            response.sendRedirect("login.jsp?error=true");
//        }
//    }
//
//    private boolean isValidUser(String username, String password) {
//        SessionFactory sessionFactory = null;
//        Session session = null;
//        Transaction tx = null;
//
//        try {
//            // Use the programmatic HibernateUtil configuration
//            sessionFactory = (SessionFactory) HibernateUtil.getSession();
//            session = sessionFactory.openSession();
//            tx = session.beginTransaction();
//
//            // Retrieve user from the database based on the provided username
//            CriteriaBuilder builder = session.getCriteriaBuilder();
//            CriteriaQuery<Student> query = builder.createQuery(Student.class);
//            Root<Student> root = query.from(Student.class);
//            query.select(root).where(builder.equal(root.get("Email"), username));
//            Query<Student> q = session.createQuery(query);
//            Student user = q.uniqueResult();
//
//            if (user != null && user.getPassword().trim().equalsIgnoreCase(password.trim())) {
//                System.out.println("Login success");
//                return true;
//            }
//            System.out.println("Login failed: incorrect credentials");
//        } catch (Exception e) {
//            if (tx != null) {
//                tx.rollback();
//            }
//            e.printStackTrace();
//        } finally {
//            try {
//                if (tx != null) {
//                    tx.commit();
//                }
//            } catch (Exception ex) {
//                ex.printStackTrace();
//            } finally {
//                if (session != null) {
//                    session.close();
//                }
//                if (sessionFactory != null) {
//                    sessionFactory.close();
//                }
//            }
//        }
//
//        return false;
//    }
//}


@WebServlet("/loginservlet")
public class loginservlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public loginservlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        SessionFactory sessionFactory = null;
        Session session = null;
        Transaction tx = null;

        try {
            String username = request.getParameter("Email");
            String password = request.getParameter("password");

            sessionFactory = HibernateUtil.getSessionFactory();
            session = sessionFactory.openSession();
            tx = session.beginTransaction();

            // Retrieve user from the database based on the provided username
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Student> query = builder.createQuery(Student.class);
            Root<Student> root = query.from(Student.class);
            query.select(root).where(builder.equal(root.get("Email"), username));
            Query<Student> q = session.createQuery(query);
            Student user = q.uniqueResult();

            if (user != null && user.getPassword().trim().equalsIgnoreCase(password.trim())) {
                System.out.println("Login success");
                // Set the user object in the session
                HttpSession userSession = request.getSession();
                userSession.setAttribute("user", user);
                response.sendRedirect("test.jsp");
            } else {
                System.out.println("Login failed: incorrect credentials");
                response.sendRedirect("login.jsp?error=true");
            }

            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            e.printStackTrace();
            response.sendRedirect("login.jsp?error=true");
        } finally {
            try {
                if (session != null) {
                    session.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
 
    
    

//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        SessionFactory sessionFactory = null;
//        Session session = null;
//        Transaction tx = null;
//
//        try {
//            String username = request.getParameter("Email");
//            String password = request.getParameter("password");
//
//            sessionFactory = HibernateUtil.getSessionFactory();
//            session = sessionFactory.openSession();
//            tx = session.beginTransaction();
//
//            // Retrieve user from the database based on the provided username
//            CriteriaBuilder builder = session.getCriteriaBuilder();
//            CriteriaQuery<Student> query = builder.createQuery(Student.class);
//            Root<Student> root = query.from(Student.class);
//            query.select(root).where(builder.equal(root.get("Email"), username));
//            Query<Student> q = session.createQuery(query);
//            Student user = q.uniqueResult();
//
//            if (user != null && user.getPassword().trim().equalsIgnoreCase(password.trim())) {
//                System.out.println("Login success");
//                response.sendRedirect("test.jsp");
//            } else {
//                System.out.println("Login failed: incorrect credentials");
//                response.sendRedirect("login.jsp?error=true");
//            }
//
//            tx.commit();
//        } catch (Exception e) {
//            if (tx != null) {
//                tx.rollback();
//            }
//            e.printStackTrace();
//            response.sendRedirect("login.jsp?error=true");
//        } finally {
//            try {
//                if (session != null) {
//                    session.close();
//                }
//            } catch (Exception ex) {
//                ex.printStackTrace();
//            }
//        }
//    }
}