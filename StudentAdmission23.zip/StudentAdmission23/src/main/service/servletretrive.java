package main.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Base64;
import java.util.List;
import javax.xml.bind.DatatypeConverter;

import main.Dao.StudentDao;
import main.Model.Student;
import main.Dao.*;
import main.Model.*;

@WebServlet("/servletretrive")
public class servletretrive extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public servletretrive() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
//    	Student std = null;
    	StudentDao dao = new StudentDao();

//        int id = Integer.parseInt(request.getParameter("lastname1"));
//
//        std = dao.searchStudent(id);
//
//        if (std != null) {
//            request.setAttribute("firstname", std.getFirstname());
//            request.setAttribute("lastname", std.getLastname());
//            request.setAttribute("email", std.getEmail());
//            request.setAttribute("id", std.getId());
//            request.getRequestDispatcher("form.jsp").forward(request, response);
//        } else {
//            System.out.println("Employee not found with id: " + id);
//        } 	
   
//==============    =====================================================	
//    	 StudentDao dao = new StudentDao();
//
//    	    int id = Integer.parseInt(request.getParameter("lastname1"));
//
//    	    // Retrieve student information from the database
//    	    Student std = dao.searchStudent(id);
//
//    	    if (std != null) {
//    	        // Get the hexadecimal image data
//    	        String hexImageData = std.getImage();
//
//    	        // Convert hexadecimal string directly to Base64
//    	        String base64Image = DatatypeConverter.printBase64Binary(DatatypeConverter.parseHexBinary(hexImageData));
//
//    	        // Set attributes in request
//    	        request.setAttribute("telephone", std.getTelephone());
//    	        request.setAttribute("image", base64Image);
//    	        request.setAttribute("faculty", std.getFaculty());
//    	        request.setAttribute("department", std.getDepartment());
//    	        request.setAttribute("firstname", std.getFirstname());
//    	        request.setAttribute("lastname", std.getLastname());
//    	        request.setAttribute("email", std.getEmail());
//    	        request.setAttribute("id", std.getId());
//
//    	        // Forward the request to the JSP page
//    	        request.getRequestDispatcher("form.jsp").forward(request, response);
//    	    } else {
//    	        System.out.println("Student not found with id: " + id);
//    	    }
//    	
    	
    	
//   ===========================================

    	int id = Integer.parseInt(request.getParameter("lastname1"));
    	Student student = dao.searchStudent(id);

    	if (student != null) {
//    	    byte[] imageData = student.getImage();
//
//    	    // Encode byte array to Base64
//    	    String base64Image = Base64.getEncoder().encodeToString(imageData);

    	    // Set attributes in request
//    	    request.setAttribute("base64Image", base64Image);
    	    request.setAttribute("telephone", student.getTelephone());
    	    request.setAttribute("faculty", student.getFaculty());
    	    request.setAttribute("department", student.getDepartment());
    	    request.setAttribute("firstname", student.getFirstname());
    	    request.setAttribute("lastname", student.getLastname());
    	    request.setAttribute("email", student.getEmail());
    	    request.setAttribute("id", student.getId());
//    	    System.out.println("Base64 Image: " + base64Image);
    	    // Forward the request to the JSP page
    	    request.getRequestDispatcher("form.jsp").forward(request, response);
    	} else {
    	    System.out.println("Student not found with id: " + id);
    	}
    }
}
