package main.service;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import main.Dao.StudentDao;
import main.Model.Student;

@WebServlet("/DisplayStudentServlet")
public class DisplayStudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String studentIdParam = request.getParameter("studentId");

        // Validate if the student ID is provided
        if (studentIdParam == null || studentIdParam.isEmpty()) {
            response.getWriter().println("Student ID is required.");
            return;
        }

        try {
            // Parse the student ID
            int studentId = Integer.parseInt(studentIdParam);

            // Fetch student record from the database based on ID
            StudentDao studentDao = new StudentDao();
            Student student = studentDao.searchStudent(studentId);

            if (student != null) {
                // Set the student object as an attribute in the request
                request.setAttribute("student", student);

                // Forward the request to the JSP to display the student information
                request.getRequestDispatcher("TestAddission.jsp").forward(request, response);
            } else {
                response.getWriter().println("Student not found with ID: " + studentId);
            }
        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid student ID format.");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
