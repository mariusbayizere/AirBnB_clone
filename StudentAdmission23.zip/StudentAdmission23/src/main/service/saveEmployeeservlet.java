package main.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import main.Dao.StudentDao;
import main.Model.Student;

/**
 * Servlet implementation class saveEmployeeservlet
 */
@WebServlet("/saveEmployeeservlet")
public class saveEmployeeservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
          
    /**
     * @see HttpServlet#HttpServlet()
     */
    public saveEmployeeservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}




	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		doGet(request, response);
		
		String firstName = request.getParameter("firstname");
		String lastName = request.getParameter("lastname");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String confirmpass = request.getParameter("password1");
		
		Student emp = new Student();
		StudentDao dao = new StudentDao();
		
		emp.setFirstname(firstName);
		emp.setLastname(lastName);
		emp.setEmail(email);
		
		if (password.equals(confirmpass))
		{
			System.out.println("there are eaqual");
			emp.setPassword(password);
			dao.saveStudent(emp);
			response.sendRedirect("login.jsp");
		}else {
		System.out.println("they are not equal");
		response.sendRedirect("signup.jsp");
		}
		
		
		
	}

}