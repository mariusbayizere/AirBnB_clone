package main.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List; 
import main.Dao.StudentDao;
import main.Model.Student;

/**
 * Servlet implementation class allempolyee
 */
@WebServlet("/allempolyee")
public class allempolyee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public allempolyee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentDao san = new StudentDao();

	    try {
	        List<Student> studentList = san.selectAllStudent();
	        System.out.println("Retrieved Data: " + studentList);
	        request.setAttribute("Student", studentList);

	        RequestDispatcher demp = request.getRequestDispatcher("allData.jsp");
	        demp.forward(request, response);
	    } catch (Exception e) {
	        e.printStackTrace();
	        // Handle the exception properly, log or throw as needed
	    }		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
